// content.js -- finds submission cards on the page, builds a review request
// per card straight from the DOM. Reads from the ClipReviewSandbox page's
// data-* attributes and data-role markers (see
// clipbait-master/client/src/pages/ClipReviewSandbox), which mirror what's
// actually visible on Whop's real review card (title, submitter, stats,
// watch-video link) plus a hidden `[data-role="external"]` block standing in
// for what apify_check.py fetches from the real post in production (bio,
// caption, pfp -- none of which Whop's own dashboard shows).
//
// When this eventually points at the real Whop dashboard, CARD_SELECTOR and
// the field selectors below will need to change to match that page's DOM,
// and verify_external should flip to true so the server fetches real data
// via Apify instead of reading the (sandbox-only) external block.

(function () {
  const BRIEF_SELECTOR = ".crs-brief pre";
  const CARD_SELECTOR = "[data-submission-id]";

  function getBriefText() {
    const el = document.querySelector(BRIEF_SELECTOR);
    return el ? el.textContent.trim() : "";
  }

  // Whop's real review card (confirmed from screenshots) shows a title,
  // submitter, stats, and a watch-video link -- NOT bio/caption/pfp, which
  // only exist on the actual post. `[data-role="external"]` is a hidden
  // element carrying that data for fast/free sandbox testing; in production
  // this stays empty and the server fetches it via apify_check.py instead
  // (see verify_external below).
  function buildPayload(card, brief) {
    const stats = card.querySelector('[data-role="stats"]');
    const external = card.querySelector('[data-role="external"]');
    return {
      submission_id: card.dataset.submissionId,
      platform: (card.querySelector(".crs-platform-icon")?.textContent || "").trim(),
      title: (card.querySelector('[data-role="title"]')?.textContent || "").trim(),
      username: external?.dataset.username || "",
      profile_name: external?.dataset.profileName || "",
      bio: external?.dataset.bio || "",
      caption: external?.dataset.caption || "",
      stats: {
        views: Number(stats?.dataset.views || 0),
        likes: stats?.dataset.likes !== undefined ? Number(stats.dataset.likes) : null,
        comments: stats?.dataset.comments !== undefined ? Number(stats.dataset.comments) : null,
        shares: stats?.dataset.shares !== undefined ? Number(stats.dataset.shares) : null,
      },
      url: stats?.dataset.url || "",
      brief,
      // false = trust bio/caption/username/images above directly (sandbox fast path).
      // Flip true once Apify actors in apify_check.py are confirmed real --
      // costs an actual Apify run per submission, and is what production should use.
      verify_external: false,
    };
  }

  function reviewSubmission(payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "REVIEW_SUBMISSION", payload }, (res) => resolve(res));
    });
  }

  function renderVerdictBadge(card, verdict, botScore, notes) {
    let badge = card.querySelector(".crb-badge");
    if (!badge) {
      badge = document.createElement("div");
      badge.className = "crb-badge";
      card.appendChild(badge);
    }
    badge.textContent = `bot: ${verdict} (bot_score ${botScore})`;
    badge.title = notes || "";
    badge.dataset.verdict = verdict;
  }

  function clickAction(card, verdict) {
    const action = verdict === "approve" || verdict === "reject" ? verdict : "flag";
    const btn = card.querySelector(`[data-action="${action}"]`);
    if (btn) btn.click();
  }

  async function reviewCard(card, brief) {
    const payload = buildPayload(card, brief);
    const external = card.querySelector('[data-role="external"]');
    const pfpSrc = external?.dataset.pfp || "";
    const pfpUri = pfpSrc.startsWith("data:") ? pfpSrc : await new Promise((resolve) => {
      if (!pfpSrc) return resolve(null);
      chrome.runtime.sendMessage({ type: "FETCH_IMAGE_AS_DATA_URI", url: pfpSrc }, (res) => resolve(res && res.ok ? res.dataUri : null));
    });
    payload.images = { pfp: pfpUri, thumbnail: null }; // Whop's real card has no inline thumbnail to capture (see buildPayload comment)

    renderVerdictBadge(card, "reviewing…", "-", "");
    const res = await reviewSubmission(payload);
    if (!res || !res.ok) {
      renderVerdictBadge(card, "error", "-", (res && res.error) || "unknown error");
      return;
    }
    const { verdict, bot_score, compliance, error } = res.data;
    renderVerdictBadge(card, verdict, bot_score, error || compliance?.notes);
    clickAction(card, verdict);
  }

  async function runOnAllCards() {
    const brief = getBriefText();
    const cards = Array.from(document.querySelectorAll(CARD_SELECTOR));
    for (const card of cards) {
      await reviewCard(card, brief); // sequential on purpose -- easier to watch/debug, and gentle on the local server
    }
  }

  // Triggered from the extension's popup (popup.js), not an injected
  // on-page button -- this content script's own job is just reading cards
  // and rendering verdict badges on them, not owning a page-level control.
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type !== "RUN_REVIEW") return undefined;
    // Both this script and content-whop.js match localhost:3000/* (needed
    // so the real click-flow can be tested against an accurate Whop-markup
    // mock, on the same origin as the original caption/bio sandbox) --
    // without this guard, both would answer the same broadcast and race,
    // same failure mode already fixed once for whop.com's outer-shell vs.
    // iframe case. `.analytics-section-bg` only exists on real (or
    // accurately mocked) Whop markup, never on this sandbox's own cards --
    // let content-whop.js take pages that have it.
    if (document.querySelector(".analytics-section-bg")) return undefined;
    const cards = document.querySelectorAll(CARD_SELECTOR);
    if (!cards.length) {
      sendResponse({ ok: false, error: "No submission cards found on this page." });
      return undefined;
    }
    sendResponse({ ok: true, count: cards.length });
    runOnAllCards(); // continues running on the page after the popup closes
    return undefined;
  });
})();
