// popup.js -- Content Rewards Clip Reviewer popup UI.
//
// Popups are fully destroyed and recreated every time they close/reopen --
// nothing here survives that. All real state lives in chrome.storage.local,
// written either by this file (whitelist, brief, theme, history) or by
// content-whop.js (progress/results, as each submission finishes) -- this
// file reads it fresh on load and live-updates via chrome.storage.onChanged
// while it stays open. The actual review loop runs independently on the
// page; this popup is just a control surface + viewer.

const STORAGE_KEY = "clipReviewProgress";
const WHITELIST_KEY = "clipReviewWhitelist";
// CUSTOM_BRIEF_KEY is the single "currently active" brief text -- the only
// thing content-whop.js actually reads (see getCustomBrief() there). Never
// renamed/removed: keeping it as the one source of truth for the active
// brief means content-whop.js doesn't need to know saved-briefs exist at
// all -- this file just keeps it in sync with whichever profile is active.
const CUSTOM_BRIEF_KEY = "clipReviewCustomBrief";
// Saved named brief profiles, so a CPE running multiple clients' campaigns
// can switch between them instead of copy/pasting in and out of one
// textarea each time -- BRIEFS_KEY holds [{id, name, text}], ACTIVE_BRIEF_ID_KEY
// tracks which one (if any) is currently loaded into CUSTOM_BRIEF_KEY.
const BRIEFS_KEY = "clipReviewBriefs";
const ACTIVE_BRIEF_ID_KEY = "clipReviewActiveBriefId";
const THEME_KEY = "crb-theme";
const HISTORY_KEY = "clipReviewHistory";
// Real subscribed state -- set true once Stripe checkout + the backend
// license check actually exist and confirm this browser is paid. Until
// then this stays false/absent and the Premium tab's gem keeps flashing.
const SUBSCRIBED_KEY = "crb-subscribed";
// Same literal key background.js's verifyAndStoreApiKey() writes -- its
// presence (not SUBSCRIBED_KEY) is what "connected at all" means; a lapsed
// subscription still leaves this set, and should show the Premium tab's
// normal nag, not send the user back through manual connection.
const API_KEY_STORAGE_KEY = "crb_api_key";
// Same literal key background.js's fetchStatus()/verifyAndStoreApiKey()
// write -- owner's email when this account is a team seat member, null for
// an owner/independent subscriber.
const SEAT_OF_KEY = "crb-seat-of";

const VERDICT_META = {
  APPROVED: { color: "var(--approved)", bgVar: "rgba(52,211,153,0.14)", label: "Approved" },
  REJECTED: { color: "var(--rejected)", bgVar: "rgba(249,100,100,0.14)", label: "Rejected" },
  SKIPPED: { color: "var(--skipped)", bgVar: "rgba(154,156,163,0.14)", label: "Skipped" },
  ERROR: { color: "var(--error)", bgVar: "rgba(245,184,77,0.14)", label: "Error" },
};

function escapeHtml(s) {
  const div = document.createElement("div");
  div.textContent = s == null ? "" : String(s);
  return div.innerHTML;
}

// --- Element refs ---------------------------------------------------------
const el = (id) => document.getElementById(id);
const themeToggleBtn = el("theme-toggle-btn");
const themeIconDark = el("theme-icon-dark");
const themeIconLight = el("theme-icon-light");
const helpBtn = el("help-btn");
const tabBtns = Array.from(document.querySelectorAll(".tab-btn"));
const tabPanels = { home: el("home-panel"), history: el("history-panel"), apps: el("apps-panel"), team: el("team-panel"), premium: el("premium-panel") };
const premiumTabBtn = el("tab-premium-btn");

const setupBanner = el("setup-banner");
const whitelistHeader = el("whitelist-header");
const whitelistBody = el("whitelist-body");
const whitelistChipsEl = el("whitelist-chips");
const whitelistEmptyEl = el("whitelist-empty");
const whitelistCountPill = el("whitelist-count-pill");
const whitelistInput = el("whitelist-input");
const whitelistAddBtn = el("whitelist-add-btn");

const campaignHeader = el("campaign-header");
const campaignBody = el("campaign-body");
const campaignBriefInput = el("campaign-brief-input");
const campaignStatusPill = el("campaign-status-pill");
const campaignSaveBtn = el("campaign-save-btn");
const briefSelect = el("brief-select");
const briefDeleteBtn = el("brief-delete-btn");
const briefNameInput = el("brief-name-input");

const runBtn = el("run-btn");
const runBtnLabel = el("run-btn-label");
const stopBtn = el("stop-btn");
const statusDot = el("status-dot");
const statusText = el("status-text");
const summarySection = el("summary-section");
const summaryChipsEl = el("summary-chips");
const clearLogsBtn = el("clear-logs-btn");
const resultsList = el("results-list");
const resultsEmpty = el("results-empty");

const historyList = el("history-list");
const historyEmpty = el("history-empty");

const planFeaturesEl = el("plan-features");
const subscribeBtn = el("subscribe-btn");
const manageSubscriptionBtn = el("manage-subscription-btn");
const subscribedBadge = el("subscribed-badge");
const teamMemberNote = el("team-member-note");
const premiumPriceRow = el("premium-price-row");
const premiumBillingNote = el("premium-billing-note");
const addSeatBtn = el("add-seat-btn");
const seatsUsedEl = el("seats-used");
const seatsChipsEl = el("seats-chips");
const seatInviteInput = el("seat-invite-input");
const seatInviteBtn = el("seat-invite-btn");
const seatsLimitHint = el("seats-limit-hint");

const connectCodeCard = el("connect-code-card");
const connectCodeInput = el("connect-code-input");
const connectCodeBtn = el("connect-code-btn");
const connectCodeError = el("connect-code-error");

// --- Theme ------------------------------------------------------------
async function resolveInitialTheme() {
  const { [THEME_KEY]: saved } = await chrome.storage.local.get(THEME_KEY);
  if (saved === "light" || saved === "dark") return saved;
  if (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches) return "dark";
  return "light";
}

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  themeIconDark.style.display = theme === "dark" ? "block" : "none";
  themeIconLight.style.display = theme === "light" ? "block" : "none";
}

async function initTheme() {
  applyTheme(await resolveInitialTheme());
}

themeToggleBtn.addEventListener("click", async () => {
  const current = document.documentElement.getAttribute("data-theme") || "light";
  const next = current === "light" ? "dark" : "light";
  applyTheme(next);
  await chrome.storage.local.set({ [THEME_KEY]: next });
});

helpBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://x.com/spiritraps" });
});

// --- Premium / subscribed state ------------------------------------------------------------
// Single source of truth (crb-subscribed, set by background.js's real auth
// handoff) driving both the gem's nag animation AND the Premium tab's own
// content. Confirmed live: the handoff itself worked (gem/storage updated
// correctly) but nothing here ever changed what the Premium tab actually
// SHOWED -- a subscribed user still saw "SUBSCRIBE TO UNLOCK" with no
// indication they'd already paid. Renamed from refreshGemFlash to cover both.
async function refreshGemFlash() {
  const { [SUBSCRIBED_KEY]: subscribed, [SEAT_OF_KEY]: seatOf } = await chrome.storage.local.get([SUBSCRIBED_KEY, SEAT_OF_KEY]);
  premiumTabBtn.classList.toggle("flash", !subscribed);
  subscribedBadge.style.display = subscribed ? "inline-flex" : "none";
  subscribeBtn.style.display = subscribed ? "none" : "flex";

  // A team seat member has full access but no Stripe customer of their
  // own -- "Manage subscription" would just 400 for them (confirmed: that
  // button calls create-portal-session, which looks up billing on THIS
  // account, and a seat member never has one -- only the owner does).
  // Swap it for a plain note instead of a button that's guaranteed to fail.
  const isTeamMember = !!(subscribed && seatOf);
  manageSubscriptionBtn.style.display = subscribed && !isTeamMember ? "flex" : "none";
  teamMemberNote.style.display = isTeamMember ? "block" : "none";
  if (isTeamMember) {
    teamMemberNote.innerHTML = `You're on <strong>${escapeHtml(seatOf)}</strong>'s team plan. Only they can manage billing.`;
  }
  if (premiumPriceRow) premiumPriceRow.style.display = isTeamMember ? "none" : "flex";
  if (premiumBillingNote) premiumBillingNote.style.display = isTeamMember ? "none" : "block";
}

// --- Manual connection fallback ------------------------------------------------------------
// Shown on Home (not Premium -- that's what made the old version confusing:
// a paste-a-key box sitting right next to "SUBSCRIBE" looked like a second,
// competing way to pay). Only relevant pre-connection, which for most users
// never happens -- the automatic chrome.runtime handoff from
// connect.html/accept-invite.html covers it. This is purely the fallback
// for when that can't reach this install.
async function refreshConnectCard() {
  const { [API_KEY_STORAGE_KEY]: apiKey } = await chrome.storage.local.get(API_KEY_STORAGE_KEY);
  connectCodeCard.classList.toggle("visible", !apiKey);
}

connectCodeBtn.addEventListener("click", async () => {
  const code = connectCodeInput.value.trim();
  if (!code) return;
  connectCodeError.style.display = "none";
  connectCodeBtn.disabled = true;
  connectCodeBtn.textContent = "Connecting…";
  try {
    const resp = await chrome.runtime.sendMessage({ type: "CONNECT_WITH_CODE", code });
    if (!resp?.ok) throw new Error(resp?.error || "invalid_code");
    connectCodeInput.value = "";
    await refreshConnectCard();
    await refreshGemFlash();
    await refreshTeamSeatsUI();
  } catch (err) {
    connectCodeError.textContent = "That code didn't work -- double check you copied the whole thing.";
    connectCodeError.style.display = "block";
  } finally {
    connectCodeBtn.disabled = false;
    connectCodeBtn.textContent = "Connect";
  }
});

connectCodeInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") connectCodeBtn.click();
});

// --- Tabs ------------------------------------------------------------
function setActiveTab(name) {
  tabBtns.forEach((btn) => btn.classList.toggle("active", btn.dataset.tab === name));
  Object.entries(tabPanels).forEach(([key, panelEl]) => panelEl.classList.toggle("active", key === name));
}

tabBtns.forEach((btn) => btn.addEventListener("click", () => setActiveTab(btn.dataset.tab)));

// --- Whitelist ------------------------------------------------------------
async function loadWhitelist() {
  const { [WHITELIST_KEY]: list } = await chrome.storage.local.get(WHITELIST_KEY);
  return list || [];
}

function renderWhitelist(list) {
  whitelistCountPill.textContent = String(list.length);
  whitelistEmptyEl.style.display = list.length === 0 ? "block" : "none";
  whitelistChipsEl.innerHTML = list.map((name) => `
    <div class="wl-chip">
      <div class="wl-chip-avatar">${escapeHtml(name.charAt(0).toUpperCase())}</div>
      <span>${escapeHtml(name)}</span>
      <button class="wl-chip-remove" data-name="${escapeHtml(name)}" title="Remove">&times;</button>
    </div>
  `).join("");
}

async function refreshWhitelistUI() {
  renderWhitelist(await loadWhitelist());
}

function setCollapse(headerEl, bodyEl, open) {
  headerEl.classList.toggle("open", open);
  bodyEl.classList.toggle("open", open);
}

whitelistHeader.addEventListener("click", () => {
  const isOpen = whitelistBody.classList.contains("open");
  setCollapse(whitelistHeader, whitelistBody, !isOpen);
});

whitelistAddBtn.addEventListener("click", async () => {
  const name = whitelistInput.value.trim().toLowerCase();
  if (!name) return;
  const list = await loadWhitelist();
  if (!list.includes(name)) {
    list.push(name);
    await chrome.storage.local.set({ [WHITELIST_KEY]: list });
  }
  whitelistInput.value = "";
  await refreshWhitelistUI();
});

whitelistInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") whitelistAddBtn.click();
});

whitelistChipsEl.addEventListener("click", async (e) => {
  const btn = e.target.closest(".wl-chip-remove");
  if (!btn) return;
  const list = (await loadWhitelist()).filter((n) => n !== btn.dataset.name);
  await chrome.storage.local.set({ [WHITELIST_KEY]: list });
  await refreshWhitelistUI();
});

// --- Campaign brief ------------------------------------------------------------
// CUSTOM_BRIEF_KEY always holds whatever's currently "active" -- that's the
// only thing content-whop.js reads. BRIEFS_KEY is purely this popup's own
// bookkeeping of named profiles so a CPE running several clients' campaigns
// can switch the active one instead of copy/pasting each time.
async function loadCustomBrief() {
  const { [CUSTOM_BRIEF_KEY]: text } = await chrome.storage.local.get(CUSTOM_BRIEF_KEY);
  return text || "";
}

async function loadBriefs() {
  const { [BRIEFS_KEY]: list } = await chrome.storage.local.get(BRIEFS_KEY);
  return list || [];
}

async function loadActiveBriefId() {
  const { [ACTIVE_BRIEF_ID_KEY]: id } = await chrome.storage.local.get(ACTIVE_BRIEF_ID_KEY);
  return id || "";
}

function genBriefId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function updateSetupBanner(briefText) {
  setupBanner.classList.toggle("visible", !briefText.trim());
}

// Repopulates the <select> from saved profiles and marks the active one --
// separate from refreshCampaignUI() (which drives the textarea/pill/banner)
// since brief-select's own onChange also needs to call this after edits.
async function refreshBriefSelect() {
  const [briefs, activeId] = await Promise.all([loadBriefs(), loadActiveBriefId()]);
  briefSelect.innerHTML = `<option value="">— New brief —</option>` +
    briefs.map((b) => `<option value="${escapeHtml(b.id)}">${escapeHtml(b.name)}</option>`).join("");
  briefSelect.value = activeId && briefs.some((b) => b.id === activeId) ? activeId : "";
  briefDeleteBtn.disabled = !briefSelect.value;
  briefNameInput.value = briefs.find((b) => b.id === briefSelect.value)?.name || "";
}

async function refreshCampaignUI({ forceOpen } = {}) {
  const text = await loadCustomBrief();
  campaignBriefInput.value = text;
  const isSet = text.trim().length > 0;
  campaignStatusPill.textContent = isSet ? "Set" : "Not set";
  campaignStatusPill.style.color = isSet ? "var(--approved)" : "var(--text-quaternary)";
  campaignStatusPill.style.background = isSet ? "rgba(52,211,153,0.14)" : "var(--chip-bg)";
  updateSetupBanner(text);
  await refreshBriefSelect();
  if (forceOpen) {
    setCollapse(campaignHeader, campaignBody, true);
  }
  return text;
}

campaignHeader.addEventListener("click", () => {
  const isOpen = campaignBody.classList.contains("open");
  setCollapse(campaignHeader, campaignBody, !isOpen);
});

// Live, not just after Save -- the banner is about "is there currently
// text in the box", so it should track what's actually typed, not lag a
// full save-cycle behind. Doesn't touch storage; just reflects the
// textarea's current value on every keystroke.
campaignBriefInput.addEventListener("input", () => {
  updateSetupBanner(campaignBriefInput.value);
});

// Switching clients is one click: pick a saved brief and it's immediately
// active (written to CUSTOM_BRIEF_KEY), not just previewed -- matches how
// someone actually uses this ("switch to whichever they need to run").
briefSelect.addEventListener("change", async () => {
  const id = briefSelect.value;
  if (!id) {
    // "— New brief —" -- clear the box for a fresh one. Also clears the
    // active brief itself (an empty one), same as manually clearing the
    // textarea and saving used to; the Run button's existing "brief
    // required" gate covers the rest.
    campaignBriefInput.value = "";
    briefNameInput.value = "";
    await chrome.storage.local.set({ [CUSTOM_BRIEF_KEY]: "" });
    await chrome.storage.local.remove(ACTIVE_BRIEF_ID_KEY);
    briefDeleteBtn.disabled = true;
    updateSetupBanner("");
    campaignStatusPill.textContent = "Not set";
    campaignStatusPill.style.color = "var(--text-quaternary)";
    campaignStatusPill.style.background = "var(--chip-bg)";
    return;
  }
  const briefs = await loadBriefs();
  const brief = briefs.find((b) => b.id === id);
  if (!brief) return;
  campaignBriefInput.value = brief.text;
  briefNameInput.value = brief.name;
  briefDeleteBtn.disabled = false;
  await chrome.storage.local.set({ [CUSTOM_BRIEF_KEY]: brief.text, [ACTIVE_BRIEF_ID_KEY]: brief.id });
  updateSetupBanner(brief.text);
  campaignStatusPill.textContent = "Set";
  campaignStatusPill.style.color = "var(--approved)";
  campaignStatusPill.style.background = "rgba(52,211,153,0.14)";
  setStatus("idle", `Switched to "${brief.name}".`, "success");
});

briefDeleteBtn.addEventListener("click", async () => {
  const id = briefSelect.value;
  if (!id) return;
  const briefs = (await loadBriefs()).filter((b) => b.id !== id);
  await chrome.storage.local.set({ [BRIEFS_KEY]: briefs });
  const activeId = await loadActiveBriefId();
  if (activeId === id) {
    await chrome.storage.local.set({ [CUSTOM_BRIEF_KEY]: "" });
    await chrome.storage.local.remove(ACTIVE_BRIEF_ID_KEY);
  }
  await refreshCampaignUI();
  setStatus("idle", "Brief deleted.", "idle");
});

campaignSaveBtn.addEventListener("click", async () => {
  const text = campaignBriefInput.value.trim();
  const name = briefNameInput.value.trim();
  const selectedId = briefSelect.value;

  if (name) {
    // Named -- upsert into the saved-profiles list. Editing an already-
    // selected profile updates it in place (including renames); typing a
    // new name while "New brief" is selected creates a fresh profile.
    const briefs = await loadBriefs();
    let brief = briefs.find((b) => b.id === selectedId);
    if (brief) {
      brief.name = name;
      brief.text = text;
    } else {
      brief = { id: genBriefId(), name, text };
      briefs.push(brief);
    }
    await chrome.storage.local.set({ [BRIEFS_KEY]: briefs, [CUSTOM_BRIEF_KEY]: text, [ACTIVE_BRIEF_ID_KEY]: brief.id });
  } else if (text) {
    // No name given -- old behavior, just an unnamed active brief, no
    // profile saved. Keeps the simple copy/paste-and-run flow working for
    // anyone who only ever runs one campaign.
    await chrome.storage.local.set({ [CUSTOM_BRIEF_KEY]: text });
    await chrome.storage.local.remove(ACTIVE_BRIEF_ID_KEY);
  } else {
    await chrome.storage.local.remove(CUSTOM_BRIEF_KEY);
    await chrome.storage.local.remove(ACTIVE_BRIEF_ID_KEY);
  }

  await refreshCampaignUI();
  setCollapse(campaignHeader, campaignBody, false); // auto-collapse on save, per design
  setStatus("idle", text ? "Campaign brief saved." : "Brief cleared -- set one before running.", text ? "success" : "idle");
});

// --- Status ------------------------------------------------------------
function setStatus(_type, text, tone) {
  // tone: 'idle' | 'success' | 'error' | 'running'
  statusText.textContent = text;
  const colorVar = tone === "error" ? "var(--rejected)" : tone === "success" ? "var(--approved)" : tone === "running" ? "var(--accent)" : "var(--text-secondary)";
  statusText.style.color = colorVar;
  statusDot.style.background = tone === "error" ? "var(--rejected)" : tone === "success" ? "var(--approved)" : tone === "running" ? "var(--accent)" : "var(--text-quaternary)";
}

// --- Results / summary rendering ------------------------------------------------------------
// Maps content-whop.js's stored shape (verdict lowercase 'approve'/'reject',
// ok/skipped/whitelisted flags, bot_score, whop_shield_score, notes,
// fetched_caption, fetched_bio) into the design's verdict-key shape.
function mapVerdict(item) {
  if (!item.ok) return "ERROR";
  // item.skipped is a real "no verdict at all" case (X/Twitter). Whitelisted
  // items are NOT that -- content-whop.js always sets verdict:"approve" for
  // them, it's a real approve that just skipped the review step. Checking
  // item.whitelisted before item.verdict used to shadow that and show every
  // whitelisted approval as "Skipped" in the popup, even once it was really
  // clicking Approve -- fixed by only checking item.skipped here and letting
  // whitelisted approvals fall through to the normal verdict check below.
  if (item.skipped) return "SKIPPED";
  if (item.verdict === "approve") return "APPROVED";
  if (item.verdict === "reject") return "REJECTED";
  return "ERROR";
}

const expandedCards = {}; // transient, per-popup-session -- resets fine on reopen

function renderResultCard(item, idx) {
  const verdictKey = mapVerdict(item);
  const meta = VERDICT_META[verdictKey];
  const botScore = Math.max(0, Math.min(100, item.bot_score || 0));
  const deg = botScore * 3.6;
  const ringGradient = `conic-gradient(${meta.color} ${deg}deg, var(--ring-track) ${deg}deg 360deg)`;
  const reason = item.notes || item.error || "";
  const caption = item.fetched_caption || "";
  const bio = item.fetched_bio || "";
  const hasRaw = !!(caption || bio);
  const cardId = "card-" + idx;
  const expanded = !!expandedCards[cardId];

  const icon = {
    APPROVED: `<svg width="15" height="15" viewBox="0 0 14 14" fill="none"><path d="M3 7.3 L5.7 10 L11 4.3" stroke="${meta.color}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path></svg>`,
    REJECTED: `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3.5 3.5 L10.5 10.5 M10.5 3.5 L3.5 10.5" stroke="${meta.color}" stroke-width="1.7" stroke-linecap="round"></path></svg>`,
    SKIPPED: `<svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M3 4 L7 7 L3 10" stroke="${meta.color}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path><path d="M8 4 L12 7 L8 10" stroke="${meta.color}" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"></path></svg>`,
    ERROR: `<svg width="15" height="15" viewBox="0 0 14 14" fill="none"><path d="M7 1.6 L13 11.6 H1 Z" stroke="${meta.color}" stroke-width="1.3" stroke-linejoin="round"></path><line x1="7" y1="5.3" x2="7" y2="8" stroke="${meta.color}" stroke-width="1.3" stroke-linecap="round"></line><circle cx="7" cy="9.7" r="0.75" fill="${meta.color}"></circle></svg>`,
  }[verdictKey];

  return `
    <div class="result-card">
      <div class="result-badge" style="background:${meta.bgVar};">${icon}</div>
      <div class="result-body">
        <div class="result-top">
          <div style="min-width:0;">
            <div class="result-title">${escapeHtml(item.title || "(untitled)")}</div>
            <div class="result-verdict-label" style="color:${meta.color};">${meta.label}</div>
          </div>
          <div class="result-ring" style="background:${ringGradient};">
            <div class="result-ring-inner">${botScore}</div>
          </div>
        </div>
        <div class="result-reason"><span class="label">Reason </span>${escapeHtml(reason)}</div>
        ${hasRaw ? `
          <button class="details-toggle ${expanded ? "open" : ""}" data-card-id="${cardId}">
            <svg width="8" height="8" viewBox="0 0 10 10"><path d="M2 1 L7 5 L2 9" fill="none" stroke="var(--text-tertiary)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"></path></svg>
            <span>${expanded ? "Hide details" : "Show details"}</span>
          </button>
          <div class="details-body ${expanded ? "open" : ""}" data-card-body="${cardId}">
            <div><span class="label">Caption </span>${escapeHtml(caption || "—")}</div>
            <div><span class="label">Bio </span>${escapeHtml(bio || "—")}</div>
            <div><span class="label">Whop score </span>${item.whop_shield_score != null ? escapeHtml(item.whop_shield_score) : "—"}</div>
          </div>
        ` : ""}
      </div>
    </div>
  `;
}

function renderSummaryAndResults(progress) {
  const reviewed = (progress && progress.reviewed) || [];

  // Summary chips
  const counts = { APPROVED: 0, REJECTED: 0, SKIPPED: 0, ERROR: 0 };
  reviewed.forEach((item) => { counts[mapVerdict(item)]++; });
  const chipsHtml = ["APPROVED", "REJECTED", "SKIPPED", "ERROR"]
    .filter((k) => counts[k] > 0)
    .map((k) => `
      <div class="summary-chip">
        <div class="summary-chip-dot" style="background:${VERDICT_META[k].color};"></div>
        <span>${counts[k]} ${VERDICT_META[k].label}</span>
      </div>
    `).join("");
  summaryChipsEl.innerHTML = chipsHtml;
  summarySection.classList.toggle("visible", reviewed.length > 0);

  // Results list (most recent first)
  resultsEmpty.style.display = reviewed.length === 0 ? "block" : "none";
  resultsList.innerHTML = [...reviewed].reverse().map((item, i) => renderResultCard(item, reviewed.length - 1 - i)).join("");

  // Run/stop/status driven off the same progress object
  const running = !!(progress && progress.running);
  runBtn.classList.toggle("running", running);
  runBtn.disabled = running;
  runBtnLabel.textContent = running ? "Reviewing…" : "Run Clip Review Bot";
  stopBtn.classList.toggle("enabled", running);
  stopBtn.style.cursor = running ? "pointer" : "not-allowed";

  if (running) {
    const currentTitle = progress && progress.currentTitle;
    setStatus("idle", currentTitle ? `Checking "${currentTitle}"…` : "Reviewing submissions on this page…", "running");
  } else if (progress && progress.stopped) {
    setStatus("idle", "Stopped -- no changes were made.", "idle");
  } else if (progress && progress.finishedAt) {
    setStatus("idle", `Done — reviewed ${reviewed.length} submission${reviewed.length === 1 ? "" : "s"}.`, "success");
  }
}

resultsList.addEventListener("click", (e) => {
  const btn = e.target.closest(".details-toggle");
  if (!btn) return;
  const cardId = btn.dataset.cardId;
  expandedCards[cardId] = !expandedCards[cardId];
  const bodyEl = resultsList.querySelector(`[data-card-body="${cardId}"]`);
  btn.classList.toggle("open", expandedCards[cardId]);
  btn.querySelector("span").textContent = expandedCards[cardId] ? "Hide details" : "Show details";
  if (bodyEl) bodyEl.classList.toggle("open", expandedCards[cardId]);
});

// --- History ------------------------------------------------------------
async function loadHistory() {
  const { [HISTORY_KEY]: list } = await chrome.storage.local.get(HISTORY_KEY);
  return list || [];
}

function summarizeForHistory(progress) {
  const reviewed = (progress && progress.reviewed) || [];
  const counts = { APPROVED: 0, REJECTED: 0, SKIPPED: 0, ERROR: 0 };
  reviewed.forEach((item) => { counts[mapVerdict(item)]++; });
  return {
    date: new Date().toLocaleString(undefined, { month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" }),
    reviewed: reviewed.length,
    approved: counts.APPROVED, rejected: counts.REJECTED, skipped: counts.SKIPPED, error: counts.ERROR,
  };
}

// Archives the previous completed session into history right before a new
// run starts -- this is the one trigger point that makes sense for "past
// review sessions" without adding a whole separate archiving flow.
async function archivePreviousSessionIfAny() {
  const { [STORAGE_KEY]: progress } = await chrome.storage.local.get(STORAGE_KEY);
  if (!progress || progress.running || !progress.reviewed || progress.reviewed.length === 0) return;
  const entry = summarizeForHistory(progress);
  const history = await loadHistory();
  history.unshift(entry);
  await chrome.storage.local.set({ [HISTORY_KEY]: history.slice(0, 50) }); // cap growth
}

async function refreshHistoryUI() {
  const history = await loadHistory();
  historyEmpty.style.display = history.length === 0 ? "block" : "none";
  historyList.innerHTML = history.map((h) => {
    const chips = ["approved", "rejected", "skipped", "error"]
      .filter((k) => h[k] > 0)
      .map((k) => {
        const key = k.toUpperCase();
        return `<div class="summary-chip"><div class="summary-chip-dot" style="background:${VERDICT_META[key].color};"></div><span>${h[k]} ${VERDICT_META[key].label}</span></div>`;
      }).join("");
    return `
      <div class="history-card">
        <div class="history-top">
          <div class="history-date">${escapeHtml(h.date)}</div>
          <div class="history-count">${h.reviewed} reviewed</div>
        </div>
        <div class="history-chips">${chips}</div>
      </div>
    `;
  }).join("");
}

// --- Run / Stop ------------------------------------------------------------
runBtn.addEventListener("click", async () => {
  const brief = await loadCustomBrief();
  if (!brief.trim()) {
    setStatus("idle", "Set a campaign brief before running.", "error");
    setCollapse(campaignHeader, campaignBody, true);
    return;
  }

  await archivePreviousSessionIfAny();

  runBtn.disabled = true;
  runBtn.classList.add("running");
  runBtnLabel.textContent = "Reviewing…";
  setStatus("idle", "Reviewing submissions on this page…", "running");

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) {
    setStatus("idle", "No active tab found.", "error");
    runBtn.disabled = false;
    runBtn.classList.remove("running");
    runBtnLabel.textContent = "Run Clip Review Bot";
    return;
  }

  chrome.tabs.sendMessage(tab.id, { type: "RUN_REVIEW" }, (res) => {
    if (chrome.runtime.lastError) {
      runBtn.disabled = false;
      runBtn.classList.remove("running");
      runBtnLabel.textContent = "Run Clip Review Bot";
      setStatus("idle", "Refresh the page to fix this -- reloading the extension doesn't reload scripts already running on an open tab. Refresh the tab, then try again.", "error");
      return;
    }
    if (!res || !res.ok) {
      runBtn.disabled = false;
      runBtn.classList.remove("running");
      runBtnLabel.textContent = "Run Clip Review Bot";
      setStatus("idle", res?.error || "No submission cards found on this page.", "error");
      return;
    }
    // Storage's onChanged listener (below) takes over rendering from here
    // as content-whop.js writes progress -- this ack just confirms it started.
  });
});

stopBtn.addEventListener("click", async () => {
  // No "is it enabled" gate here on purpose -- that was gated behind the
  // .enabled CSS class, which only gets set once the storage-sync
  // listener catches up. Confirmed live: clicking Stop while that hadn't
  // landed yet (e.g. right after reopening the popup mid-run) silently
  // no-opped. STOP_REVIEW is always safe to send -- content-whop.js's
  // handler just sets a flag, no guard needed on this end either.
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { type: "STOP_REVIEW" }, () => {
      // Ignore lastError -- if the page/content script is gone, there's
      // nothing left there to stop; the direct storage write below is
      // what actually unsticks the popup in that case.
    });
  }

  // Confirmed live: relying only on the message above left the popup stuck
  // on "Reviewing..." forever with Stop doing nothing visible, until
  // "Clear Logs" was clicked -- meaning content-whop.js's own
  // finishProgress() never ran (most likely the real Whop page tore down
  // that script's context, e.g. a full SPA navigation, mid-run, so the
  // try/finally in runAllCards() never got a chance to execute). The popup
  // doesn't need to wait on a page that may already be gone -- it owns the
  // same chrome.storage.local, so Stop flips running:false itself right
  // here, immediately, regardless of whether the message above lands. If
  // the content script IS still alive, it'll also call finishProgress()
  // shortly after (harmless -- same end state, just written twice).
  const { [STORAGE_KEY]: progress } = await chrome.storage.local.get(STORAGE_KEY);
  if (progress && progress.running) {
    await chrome.storage.local.set({
      [STORAGE_KEY]: { ...progress, running: false, stopped: true, finishedAt: Date.now() },
    });
  }
});

clearLogsBtn.addEventListener("click", async () => {
  await chrome.storage.local.remove(STORAGE_KEY);
  renderSummaryAndResults(null);
});

// --- Team seats ------------------------------------------------------------
// Real backend calls now (routes/contentRewardsBot.js, via background.js so
// the API key stays in one place) -- this used to fake everything in
// chrome.storage.local with no real invite ever sent. Confirmed live: a
// "teammate" typed in here never got an email, because nothing backed it.
async function refreshTeamSeatsUI() {
  seatInviteInput.disabled = true;
  seatInviteBtn.disabled = true;

  chrome.runtime.sendMessage({ type: "FETCH_STATUS" }, (resp) => {
    if (!resp || !resp.ok) {
      // Not connected/subscribed yet -- show the owner-only baseline and
      // leave inviting disabled rather than surfacing a raw error here;
      // the Premium tab is where "you're not subscribed" actually belongs.
      seatsUsedEl.textContent = "1";
      seatsChipsEl.innerHTML = `
        <div class="wl-chip seat-chip-owner" title="This account">
          <div class="wl-chip-avatar">Y</div>
          <span>You (Owner)</span>
        </div>
      `;
      seatsLimitHint.classList.remove("visible");
      return;
    }

    const { seats = [], seatCap = 3, seatsUsed = 1 } = resp.status;
    seatsUsedEl.textContent = String(seatsUsed);
    document.getElementById("seats-cap").textContent = String(seatCap);

    seatsChipsEl.innerHTML = `
      <div class="wl-chip seat-chip-owner" title="This account">
        <div class="wl-chip-avatar">Y</div>
        <span>You (Owner)</span>
      </div>
    ` + seats.map((s) => `
      <div class="wl-chip">
        <div class="wl-chip-avatar">${escapeHtml(s.email.charAt(0).toUpperCase())}</div>
        <span>${escapeHtml(s.email)}${s.status === "pending" ? " (pending)" : ""}</span>
        <button class="wl-chip-remove" data-email="${escapeHtml(s.email)}" title="Remove">&times;</button>
      </div>
    `).join("");

    const atCap = seatsUsed >= seatCap;
    seatInviteInput.disabled = atCap;
    seatInviteBtn.disabled = atCap;
    seatsLimitHint.classList.toggle("visible", atCap);
  });
}

const EMAIL_RE = /^\S+@\S+\.\S+$/;

seatInviteBtn.addEventListener("click", async () => {
  const email = seatInviteInput.value.trim();
  if (!email) return;
  if (!EMAIL_RE.test(email)) {
    seatInviteInput.style.borderColor = "var(--rejected)";
    setTimeout(() => { seatInviteInput.style.borderColor = ""; }, 1200);
    return;
  }
  seatInviteBtn.disabled = true;
  const original = seatInviteBtn.textContent;
  seatInviteBtn.textContent = "Inviting…";
  chrome.runtime.sendMessage({ type: "INVITE_SEAT", email }, async (resp) => {
    seatInviteBtn.textContent = original;
    if (!resp || !resp.ok) {
      setStatus("idle", resp?.error || "Couldn't invite that email.", "error");
      seatInviteBtn.disabled = false;
      return;
    }
    seatInviteInput.value = "";
    setStatus("idle", `Invite sent to ${email}.`, "success");
    await refreshTeamSeatsUI();
  });
});

seatInviteInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") seatInviteBtn.click();
});

seatsChipsEl.addEventListener("click", async (e) => {
  const btn = e.target.closest(".wl-chip-remove");
  if (!btn) return;
  const email = btn.dataset.email;
  chrome.runtime.sendMessage({ type: "REMOVE_SEAT", email }, async (resp) => {
    if (!resp || !resp.ok) {
      setStatus("idle", resp?.error || "Couldn't remove that seat.", "error");
      return;
    }
    await refreshTeamSeatsUI();
  });
});

// --- Premium (UI only -- no real Stripe integration exists yet) ------------------------------------------------------------
const PLAN_FEATURES = [
  { label: "Autonomous review, approve & reject clips", val: "Unlimited" },
  { label: "Whitelisted editors", val: "Unlimited" },
  { label: "Saved campaign briefs, switch clients", val: "Unlimited" },
  { label: "Priority review speed" },
  { label: "Priority support" },
];

planFeaturesEl.innerHTML = PLAN_FEATURES.map((f) => `
  <div class="plan-feature-row">
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none" style="flex-shrink:0;"><path d="M3 7.3 L5.7 10 L11 4.3" stroke="#34d399" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"></path></svg>
    <div class="plan-feature-label">${escapeHtml(f.label)}</div>
    ${f.val ? `<div class="plan-feature-val">${escapeHtml(f.val)}</div>` : ""}
  </div>
`).join("");

// Deliberately not wired to any real checkout -- no Stripe integration is
// live yet. Just acknowledges the click so the button isn't dead-feeling.
// Checkout itself (Google sign-in + Stripe) is a full page flow -- not
// something to cram into a 360x600 popup. Opens the real marketing site in
// a new tab, same as helpBtn does for the X link.
subscribeBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "https://clipreviewbot.clipbait.ai/" });
});

manageSubscriptionBtn.addEventListener("click", () => {
  const original = manageSubscriptionBtn.textContent;
  manageSubscriptionBtn.textContent = "Opening…";
  manageSubscriptionBtn.disabled = true;
  chrome.runtime.sendMessage({ type: "OPEN_BILLING_PORTAL" }, (resp) => {
    manageSubscriptionBtn.textContent = original;
    manageSubscriptionBtn.disabled = false;
    if (!resp || !resp.ok) {
      setStatus("idle", resp?.error || "Couldn't open billing portal.", "error");
    }
  });
});

// Same placeholder treatment as Subscribe -- no live per-seat billing exists
// yet (needs the Stripe subscription-item-quantity wiring on the backend).
addSeatBtn.addEventListener("click", () => {
  const original = addSeatBtn.innerHTML;
  addSeatBtn.innerHTML = "Coming soon";
  setTimeout(() => { addSeatBtn.innerHTML = original; }, 1600);
});

// --- Storage-driven live updates ------------------------------------------------------------
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[STORAGE_KEY]) renderSummaryAndResults(changes[STORAGE_KEY].newValue);
  if (changes[WHITELIST_KEY]) renderWhitelist(changes[WHITELIST_KEY].newValue || []);
  if (changes[HISTORY_KEY]) refreshHistoryUI();
  if (changes[SUBSCRIBED_KEY] || changes[SEAT_OF_KEY]) { refreshGemFlash(); refreshTeamSeatsUI(); }
  if (changes[API_KEY_STORAGE_KEY]) refreshConnectCard();
});

// --- Init ------------------------------------------------------------
(async function init() {
  await initTheme();
  await refreshWhitelistUI();
  const briefText = await refreshCampaignUI();
  setCollapse(whitelistHeader, whitelistBody, false);
  setCollapse(campaignHeader, campaignBody, !briefText.trim()); // open until first save
  await refreshHistoryUI();
  await refreshGemFlash();
  await refreshTeamSeatsUI();
  await refreshConnectCard();

  const { [STORAGE_KEY]: progress } = await chrome.storage.local.get(STORAGE_KEY);
  renderSummaryAndResults(progress);
  if (!progress || (!progress.running && !progress.reviewed?.length)) {
    setStatus("idle", "Ready. Set a campaign brief, then run the bot.", "idle");
  }
})();
