// content-whop.js -- targets the REAL Whop Content Rewards review screen
// (an embedded app, likely served from an *.apps.whop.com iframe -- that's
// why manifest.json sets all_frames:true for this entry). Separate from
// content.js (the ClipReviewSandbox script) so sandbox testing stays
// untouched while this gets real selectors as they're confirmed for real.
//
// LIVE: reviewCard() reads the page, calls the review server, and clicks
// Approve/Reject (never Ban) based on the verdict via clickVerdict() below.
// Proven out first against the click-test sandbox before being turned on
// for the real Whop dashboard -- see CLICKING_ENABLED below.
//
// Confirmed real DOM markers (2026-08, from a live HTML dump of one
// submission's review card -- these are custom class names, not
// auto-generated Tailwind utility classes, so they should be reasonably
// stable):
//   .btn-accept-container / .btn-reject-container / .btn-flag-container -- action buttons
//   .analytics-section-bg -- section wrappers (title/submitter block, stats block)
//   .shield-score-text -- Whop's OWN trust/risk score (e.g. "80") -- read
//       and report this alongside our own bot_score, don't only trust ours
//   .pill-neutral-text -- status pill text ("Pending" etc.)
//   video[src] pointing at cdn.contentrewards.com -- Whop hosts a direct
//       downloadable copy of the clip; send this as video_url (server
//       tries it first, falls back to yt-dlp against the original post
//       URL if it's not playable -- see apify_check.get_video)
//
// REJECT TOAST -- confirmed from a full real HTML dump (2026-08) of the
// bottom-right toast that appears on clicking .btn-reject-container. This
// is ONE persistent toast that expands in place, not two separate views --
// earlier notes (and the first sandbox mock) wrongly modeled it as
// swapping between a "confirm" toast and a separate "reason" toast:
//   Header row (always visible while the toast is open):
//     .toast-title-text -- "Reject this submission?"
//     "Give reason" button (btn-ghost-container, text found via textContent)
//     .btn-warning-container "Ban" -- ALSO present here, not just in the
//         main card actions row. NEVER click this, in either location --
//       banning an account is far more severe and harder to reverse than
//       rejecting one clip; nothing about this bot's job calls for it, ever.
//     an unlabeled "X" close button (img icon only, no text) -- closes the
//       toast without rejecting; not used by clickVerdict()
//   Expandable section below the header (CSS grid-rows 0fr -> expanded,
//   NOT a separate toast -- collapsed by default, revealed by "Give reason"):
//     input[placeholder="Reason for rejection..."] (React-controlled --
//         needs the native-setter trick, not el.value=) + a
//         .btn-primary-container "Submit" button right next to it,
//         disabled (real `disabled` attribute + opacity-50 class) until
//         the input has text
//     .toast-quick-select-btn -- 4 generic reason chips, shown alongside
//         the input once expanded (real text: "Content doesn't meet
//         campaign requirements", "Low quality content", "Inappropriate
//         content", "Wrong campaign guidelines") -- explicitly NOT used;
//         a specific, clip-relevant reason (compliance.notes from Gemini)
//         is typed into the input instead, per explicit instruction
//
// TIMING: the reject confirmation toast auto-dismisses after ~5 seconds.
// "Give reason" must be clicked immediately -- this polls every 50ms
// rather than using any fixed delay.
//
// This is a SCROLLABLE LIST of many submission cards (confirmed from a
// real screenshot), not a single-focused view -- getCardElements() finds
// every card's wrapper by walking up from each Approve button until it
// reaches an ancestor that also contains that card's stats block, then
// all extraction is scoped to that one card. runAllCards() reviews every
// visible card, then scrolls for more (the list lazy-loads further cards
// as you scroll) until a couple of scrolls in a row produce no new ones.
//
// Campaign brief always comes from the popup's "Campaign brief" textarea
// (CUSTOM_BRIEF_KEY below) -- there is no built-in/test brief. The popup's
// own Run button refuses to start a run until one is saved, so by the time
// runAllCards() gets here a brief is expected to exist.

(function () {
  // Prints once per frame the instant this script loads -- if you click
  // "Run Clip Review Bot" and get "Couldn't reach this page", check this
  // tab's own console (not the popup's) for this line. If it's missing,
  // the content script was never injected into this page load -- reloading
  // the extension in chrome://extensions does NOT retroactively inject
  // into tabs that were already open; you have to refresh the Whop tab
  // itself after every extension reload.
  console.log("[clip-review-bot] content-whop.js loaded on", window.location.href);

  // This exact script runs on both the real Whop dashboard AND the local
  // click-test sandbox (that's the point -- test the real code, not a
  // copy). Real clicking is live on both now, proven out against the
  // sandbox first before being turned on for whop.com/apps.whop.com.
  const CLICKING_ENABLED = /^localhost:3000$|(^|\.)app\.clipbait\.ai$|(^|\.)whop\.com$|\.apps\.whop\.com$/.test(window.location.host);

  function findByText(selector, text) {
    return Array.from(document.querySelectorAll(selector)).find(
      (el) => el.textContent.trim().toLowerCase() === text.toLowerCase()
    );
  }

  function pollFor(check, { timeoutMs = 2000, intervalMs = 50 } = {}) {
    return new Promise((resolve) => {
      const deadline = Date.now() + timeoutMs;
      const tick = () => {
        const found = check();
        if (found) return resolve(found);
        if (Date.now() > deadline) return resolve(null);
        setTimeout(tick, intervalMs);
      };
      tick();
    });
  }

  // React-controlled inputs ignore a plain `el.value = x` -- go through
  // the native setter and dispatch a real input event so React's onChange
  // actually fires and "Submit" becomes enabled.
  function setReactInputValue(input, value) {
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    setter.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  }

  // Whop's own UI already flags this directly -- far more reliable than
  // trying to infer "deleted" from a failed Apify fetch (which just looks
  // like "couldn't resolve this post" and could mean lots of things).
  // Two independent signals, checked because they don't always both show:
  //  1. A dedicated status pill (confirmed real, from an actual deleted
  //     Instagram submission's HTML): `.pill-error-text` reading "Deleted",
  //     same design-system pattern as the already-known `.pill-neutral-text`
  //     "Pending" pill.
  //  2. YouTube specifically also renders "Video unavailable -- This video
  //     has been removed by the uploader" in the player area -- but this
  //     text apparently does NOT appear for every platform's deleted post
  //     (confirmed: a deleted Instagram submission showed only the pill,
  //     not this text), so it can't be relied on alone.
  function isDeletedVideo(scope) {
    const pill = Array.from(scope.querySelectorAll(".pill-error-text")).some(
      (el) => el.textContent.trim().toLowerCase() === "deleted"
    );
    if (pill) return true;
    const text = scope.textContent || "";
    return /video unavailable/i.test(text) && /removed by the uploader/i.test(text);
  }

  function detectPlatform(url) {
    if (!url) return "";
    if (url.includes("tiktok")) return "TikTok";
    if (url.includes("instagram")) return "Instagram";
    if (url.includes("youtu")) return "YouTube";
    if (url.includes("x.com") || url.includes("twitter.com")) return "X";
    return "";
  }

  // Finds every card's wrapper: start from each Approve button (exactly
  // one per card) and walk up until reaching an ancestor that also
  // contains that card's stats/title block -- the smallest such ancestor
  // is the card. Bounded to 8 levels so a missing match can't walk all
  // the way to <body> and merge every card into one.
  function getCardElements() {
    const acceptButtons = Array.from(document.querySelectorAll(".btn-accept-container"));
    const cards = [];
    for (const btn of acceptButtons) {
      let node = btn;
      for (let i = 0; i < 8 && node.parentElement; i++) {
        node = node.parentElement;
        if (node.querySelector(".analytics-section-bg")) {
          cards.push(node);
          break;
        }
      }
    }
    return cards;
  }

  // Stable-ish identity for a card across re-renders (e.g. after
  // scrolling triggers more to load) -- the video/original-post URL is
  // the most stable thing available, since there's no submission id
  // visible anywhere in the DOM.
  //
  // Falls back to title+submitter when there's no URL at all -- confirmed
  // live bug: a DELETED submission legitimately has no video/original URL,
  // so this returned null, and runAllCards()'s `if (!key) continue` threw
  // the card away before reviewCard() (where isDeletedVideo() lives) ever
  // ran. A card with no URL and no title/submitter either is degenerate
  // enough that returning null is still fine -- nothing to key on.
  function cardKey(data) {
    return data.videoUrl || data.originalUrl || (data.title && data.whopSubmitter ? `${data.title}::${data.whopSubmitter}` : null);
  }

  function getSubmissionData(scope) {
    const sections = scope.querySelectorAll(".analytics-section-bg");
    let title = "", submitter = "";
    if (sections[0]) {
      const ps = sections[0].querySelectorAll("p");
      if (ps[0]) title = ps[0].textContent.trim();
      const submitterP = sections[0].querySelector("button p");
      // This is the clipper's WHOP account name, not their real social
      // media username -- those can legitimately differ. Keep it only for
      // logging/traceability; never feed it into the payload as `username`,
      // which Gemini uses for real impersonation/compliance judgment. The
      // real username can only come from the actual post (via Apify).
      if (submitterP) submitter = submitterP.textContent.trim();
    }

    const video = scope.querySelector('video[src*="contentrewards.com"]') || scope.querySelector("video[src]");
    const videoUrl = video ? video.src : "";

    const originalLink = scope.querySelector(
      'a[href*="tiktok.com"], a[href*="instagram.com"], a[href*="youtube.com"], a[href*="youtu.be"], a[href*="x.com"]'
    );
    const originalUrl = originalLink ? originalLink.href : "";

    const stats = { views: 0, likes: null, comments: null, shares: null };
    for (const btn of scope.querySelectorAll(".analytics-section-bg button")) {
      const ps = btn.querySelectorAll("p");
      const label = ps[0]?.textContent.trim().toLowerCase();
      const num = Number(ps[1]?.textContent.trim().replace(/,/g, ""));
      if (!label || Number.isNaN(num)) continue;
      if (label === "views") stats.views = num;
      if (label === "likes") stats.likes = num;
      if (label === "comments") stats.comments = num;
      if (label === "shares") stats.shares = num;
    }

    const shieldEl = scope.querySelector(".shield-score-text");
    const whopShieldScore = shieldEl ? Number(shieldEl.textContent.trim()) : null;

    return { title, whopSubmitter: submitter, videoUrl, originalUrl, stats, whopShieldScore, platform: detectPlatform(originalUrl) };
  }

  function reviewSubmission(payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: "REVIEW_SUBMISSION", payload }, resolve);
    });
  }

  // Trusted editors (by Whop account name) whose submissions skip review
  // entirely and always approve -- managed from the popup, not code, so
  // this list can change without touching the extension. Checking against
  // the Whop submitter name (not the social media username) is deliberate
  // here: this whitelist is about trusting a specific WHOP account/person,
  // not about the content of any one social post.
  const WHITELIST_KEY = "clipReviewWhitelist";

  async function isWhitelisted(whopSubmitter) {
    if (!whopSubmitter) return false;
    const { [WHITELIST_KEY]: list } = await chrome.storage.local.get(WHITELIST_KEY);
    return !!(list && list.includes(whopSubmitter.trim().toLowerCase()));
  }

  // Set from the popup's "Campaign brief" textarea -- this is the ONLY
  // source of the brief text sent to the review server. No campaign_id
  // lookup, no Clipbait API call, no hardcoded fallback -- just whatever's
  // pasted there, verbatim, for whichever campaign this is running against.
  const CUSTOM_BRIEF_KEY = "clipReviewCustomBrief";

  async function getCustomBrief() {
    const { [CUSTOM_BRIEF_KEY]: text } = await chrome.storage.local.get(CUSTOM_BRIEF_KEY);
    return text || null;
  }

  // Popups are fully destroyed and recreated every time you close/reopen
  // them -- any state kept only in popup.js's memory is gone the instant
  // you click away, which is exactly the bug reported ("click off and
  // click back, everything is reset"). chrome.storage.local persists
  // across that; popup.js reads it on open and live-updates via
  // chrome.storage.onChanged while it's open.
  const STORAGE_KEY = "clipReviewProgress";

  async function resetProgress() {
    await chrome.storage.local.set({
      [STORAGE_KEY]: { startedAt: Date.now(), running: true, reviewed: [] },
    });
  }

  async function appendProgress(entry) {
    const { [STORAGE_KEY]: progress } = await chrome.storage.local.get(STORAGE_KEY);
    const reviewed = (progress?.reviewed || []).concat(entry);
    await chrome.storage.local.set({
      [STORAGE_KEY]: { ...progress, reviewed },
    });
  }

  async function finishProgress(stopped = false) {
    const { [STORAGE_KEY]: progress } = await chrome.storage.local.get(STORAGE_KEY);
    await chrome.storage.local.set({
      [STORAGE_KEY]: { ...progress, running: false, stopped, finishedAt: Date.now() },
    });
  }

  // Live "what's it looking at right now" indicator, read by popup.js while
  // running is true -- separate from appendProgress, which only fires once
  // a card's verdict is already known. Without this the popup has nothing
  // to show but a static "Reviewing..." for however long the real
  // Apify+Gemini call takes, which reads as stalled even when it isn't.
  async function setCurrentlyReviewing(title) {
    const { [STORAGE_KEY]: progress } = await chrome.storage.local.get(STORAGE_KEY);
    if (!progress) return;
    await chrome.storage.local.set({ [STORAGE_KEY]: { ...progress, currentTitle: title || "" } });
  }

  async function reviewCard(cardEl) {
    const data = getSubmissionData(cardEl);
    await setCurrentlyReviewing(data.title);

    // Deleted video -- checked before even the whitelist, since a deleted
    // video isn't reviewable no matter who submitted it. Whop's own page
    // already knows this; no point burning an Apify+Gemini call to
    // eventually arrive at the same "no real data" conclusion the hard way.
    if (isDeletedVideo(cardEl)) {
      const notes = "Video was deleted by the uploader.";
      console.log(
        `%c REJECTED %c "${data.title}" -- ${notes}`,
        "background:#ef4444;color:#000;font-weight:700;border-radius:3px;padding:2px 6px;", "color:inherit;"
      );
      // Real clicking (see CLICKING_ENABLED above), same as the main review
      // path below -- this used to only log "reject" without ever actually
      // clicking, which meant a deleted submission never got physically
      // rejected even once real clicking was proven out and turned on.
      if (CLICKING_ENABLED) {
        await clickVerdict(cardEl, "reject", notes);
      }
      await appendProgress({ title: data.title, ok: true, verdict: "reject", bot_score: 0, notes, at: Date.now() });
      return { ok: true, verdict: "reject", notes };
    }

    // Whitelisted editors skip review entirely -- checked before even the
    // video/link lookup, since a whitelisted submission should approve no
    // matter what (and this also saves an Apify+Gemini call on every one
    // of their submissions).
    if (await isWhitelisted(data.whopSubmitter)) {
      console.log(
        `%c APPROVED %c "${data.title}" -- whitelisted editor (${data.whopSubmitter}), skipped review.`,
        "background:#22c55e;color:#000;font-weight:700;border-radius:3px;padding:2px 6px;", "color:inherit;"
      );
      const notes = `Whitelisted editor (${data.whopSubmitter}) -- skipped review.`;
      // Confirmed live bug: this branch recorded verdict:"approve" but never
      // actually clicked Approve on Whop's real button -- only the deleted-
      // video branch above did that. A whitelisted submission sat there
      // still "Pending" even though the log/popup said APPROVED.
      if (CLICKING_ENABLED) {
        await clickVerdict(cardEl, "approve", notes);
      }
      await appendProgress({ title: data.title, ok: true, verdict: "approve", bot_score: 0, whitelisted: true, notes, at: Date.now() });
      return { ok: true, verdict: "approve", whitelisted: true, notes };
    }

    if (!data.videoUrl && !data.originalUrl) {
      return { ok: false, error: "Couldn't find a video or original post link on this card." };
    }

    // X/Twitter has no working scraper right now (3 different Apify
    // actors tested, all broken) -- rather than guess with no real
    // caption/bio data, or false-reject every X submission, skip it
    // outright and leave it for a human. No verdict at all, not even
    // REJECTED -- an unreviewed clip should never look like a judged one.
    if (data.platform === "X") {
      console.log(`%c SKIPPED %c "${data.title}" -- X/Twitter isn't supported by the bot yet, needs a human look.`, "background:#71717a;color:#000;font-weight:700;border-radius:3px;padding:2px 6px;", "color:inherit;");
      await appendProgress({ title: data.title, ok: true, skipped: true, notes: "X/Twitter isn't supported by the bot yet -- needs a human look.", at: Date.now() });
      return { ok: true, skipped: true, notes: "X/Twitter isn't supported by the bot yet -- needs a human look." };
    }

    const payload = {
      submission_id: data.originalUrl || data.videoUrl,
      platform: data.platform || "unknown",
      title: data.title,
      // No `username` here on purpose -- the Whop submitter name
      // (data.whopSubmitter) is that clipper's WHOP account identity, not
      // necessarily their real social media handle. The real one only
      // comes from the actual post via Apify (verify_external below); if
      // that fails, server.py correctly reports "unknown" rather than
      // silently judging impersonation/compliance against the wrong name.
      stats: data.stats,
      url: data.originalUrl,
      video_url: data.videoUrl,
      // Whatever's saved in the popup's "Campaign brief" textarea -- the
      // popup's Run button already refuses to start a run without one saved.
      brief: await getCustomBrief(),
      verify_external: true, // bio/caption/real username aren't shown on Whop's page -- fetch via Apify
    };

    const res = await reviewSubmission(payload);
    if (!res || !res.ok) {
      console.warn("[clip-review-bot] review failed:", data.title, res?.error);
      await appendProgress({ title: data.title, ok: false, error: (res && res.error) || "Review request failed.", at: Date.now() });
      return { ok: false, error: (res && res.error) || "Review request failed." };
    }

    const { verdict, bot_score, compliance, error, fetched_caption, fetched_bio } = res.data;
    // For an approve carrying a minor creator_note (e.g. "bio wording
    // doesn't match exactly, fix next time"), lead with that rather than
    // the full notes dump -- it's the one line the creator actually needs
    // to act on, not a debug trace of every field checked.
    const reasonText = error || (verdict === "approve" && compliance?.creator_note) || compliance?.notes || "";
    // The verdict word itself (APPROVED/REJECTED/FLAGGED) plus the reason
    // needs to be readable in the log line at a glance, not just present
    // somewhere inside a collapsed object -- this is the primary line to
    // scan while watching a run.
    // Binary approve/reject only -- server.py no longer emits "flag".
    const VERDICT_LABELS = { approve: "APPROVED", reject: "REJECTED" };
    const VERDICT_COLORS = { approve: "#22c55e", reject: "#ef4444" };
    const verdictLabel = VERDICT_LABELS[verdict] || String(verdict).toUpperCase();
    const verdictColor = VERDICT_COLORS[verdict] || "#facc15";
    // %c-styled so this line visually pops out (colored badge) from the
    // console clutter of the raw object dump right after it -- easy to
    // miss otherwise when scanning a long run.
    console.log(
      `%c ${verdictLabel} %c "${data.title}"${reasonText ? `\nReason: ${reasonText}` : ""}`,
      `background:${verdictColor};color:#000;font-weight:700;border-radius:3px;padding:2px 6px;`,
      "color:inherit;font-weight:normal;"
    );
    // Logged explicitly (not just folded into compliance.notes) so it's
    // obvious at a glance whether Apify actually returned a blank
    // caption/bio -- vs. the creator's real post simply having none. If
    // this consistently shows "(blank)" for accounts you can see have a
    // real caption/bio when you open the post yourself, that's an Apify
    // scrape problem, not a real compliance violation.
    console.log(
      `[clip-review-bot] caption: "${fetched_caption || "(blank)"}"\n[clip-review-bot] bio: "${fetched_bio || "(blank)"}"`
    );
    console.log("[clip-review-bot]", {
      title: data.title, whop_submitter: data.whopSubmitter,
      verdict, bot_score, whop_shield_score: data.whopShieldScore,
      compliance, error, fetched_caption, fetched_bio,
    });

    await appendProgress({
      title: data.title, ok: true, verdict, bot_score,
      whop_shield_score: data.whopShieldScore,
      notes: reasonText,
      fetched_caption: fetched_caption || "",
      fetched_bio: fetched_bio || "",
      at: Date.now(),
    });

    // Real clicking (see CLICKING_ENABLED above) -- live on the actual Whop
    // dashboard now, proven out first against the click-test sandbox.
    if (CLICKING_ENABLED) {
      await clickVerdict(cardEl, verdict, error || compliance?.notes);
    }

    return {
      ok: true,
      verdict,
      bot_score,
      whop_shield_score: data.whopShieldScore,
      notes: reasonText,
    };
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // Set by the STOP_REVIEW message handler below (popup's stop button).
  // Checked between cards and between scroll passes so a stop request
  // takes effect quickly without aborting an in-flight Apify+Gemini call.
  let stopRequested = false;

  async function runAllCards() {
    stopRequested = false;
    await resetProgress();
    const seen = new Set();
    let reviewed = 0;
    let staleScrolls = 0;

    // Confirmed live: this whole loop had no error handling at all. On
    // the real Whop page, clickVerdict() interacts with real DOM nodes
    // that Whop's own React app can remove/replace right after a real
    // rejection succeeds (unlike the static sandbox) -- if that, or
    // anything else, ever throws, the ENTIRE function used to die
    // silently: finishProgress() never ran, `running` stayed stuck true
    // in storage forever, the popup showed "Reviewing..." permanently,
    // and Stop had nothing left running to even notice stopRequested.
    // try/finally guarantees finishProgress() always runs no matter how
    // this exits; the inner try/catch keeps one bad card from killing
    // every card after it.
    try {
      // Raised from 3 -- 1200ms between scrolls was likely too short for a
      // real network round-trip to fetch+render more cards on the live
      // site (only tuned against the sandbox's own simulated 800ms delay),
      // so a still-loading page could get miscounted as "no more cards"
      // and the loop would give up early even though more existed below.
      // More attempts + a longer wait (below) gives a slow real fetch room
      // to actually finish before being written off as stale.
      while (staleScrolls < 5 && !stopRequested) {
        const cards = getCardElements();
        let sawNewThisPass = false;

        for (const cardEl of cards) {
          if (stopRequested) break;
          const data = getSubmissionData(cardEl);
          const key = cardKey(data);
          if (!key || seen.has(key)) continue;
          seen.add(key);
          sawNewThisPass = true;

          try {
            await reviewCard(cardEl);
          } catch (e) {
            console.error(`[clip-review-bot] reviewCard threw for "${data.title}" -- skipping to the next card:`, e);
            await appendProgress({ title: data.title, ok: false, error: `Unexpected error: ${e}`, at: Date.now() });
          }
          reviewed++;
          await sleep(300); // gentle pacing -- each review is a real Apify+Gemini call
        }

        if (stopRequested) break;
        staleScrolls = sawNewThisPass ? 0 : staleScrolls + 1;

        // Scroll the last known card into view -- lets the browser figure
        // out which ancestor actually scrolls (window vs. an inner
        // virtualized container) rather than guessing. Followed by a bit of
        // extra overshoot: many infinite-scroll implementations trigger
        // their fetch when a sentinel/threshold slightly PAST the last
        // rendered item enters the viewport, not exactly at it -- landing
        // precisely on the last card via scrollIntoView(block:"end") can
        // undershoot that trigger point and never actually fire the site's
        // own load-more logic.
        const lastCard = cards[cards.length - 1];
        if (lastCard) lastCard.scrollIntoView({ behavior: "instant", block: "end" });
        window.scrollBy(0, 500);

        await sleep(2500); // give a real network fetch+render time to finish before checking again
      }
    } catch (e) {
      console.error("[clip-review-bot] runAllCards crashed unexpectedly:", e);
    } finally {
      if (stopRequested) console.log("[clip-review-bot] stopped by user after", reviewed, "submissions.");
      await finishProgress(stopRequested);
    }

    return { ok: true, count: reviewed, stopped: stopRequested };
  }

  async function clickVerdict(cardEl, verdict, reasonText) {
    // Step-by-step logging throughout -- the whole reject flow (click,
    // wait for the toast, click "Give reason", type, wait for Submit,
    // click Submit) typically completes in under a second, easy to miss
    // just watching the page. This makes each step unmistakable in the
    // console regardless of how fast it happens on screen.
    if (verdict === "approve") {
      const acceptBtn = cardEl.querySelector(".btn-accept-container");
      if (!acceptBtn) {
        console.warn("[clip-review-bot] clickVerdict: .btn-accept-container not found on this card.");
        return;
      }
      console.log("[clip-review-bot] clickVerdict: clicking Approve...");
      acceptBtn.click();
      console.log("[clip-review-bot] clickVerdict: Approve clicked.");
      return;
    }

    if (verdict === "reject") {
      const rejectBtn = cardEl.querySelector(".btn-reject-container");
      if (!rejectBtn) {
        console.warn("[clip-review-bot] clickVerdict: .btn-reject-container not found on this card.");
        return;
      }
      console.log("[clip-review-bot] clickVerdict: clicking Reject...");
      rejectBtn.click();

      // A deliberate pause here, not just pollFor's own polling loop.
      // pollFor's FIRST check runs synchronously -- if React has already
      // updated the DOM by the time that runs (which it can, same tick),
      // the whole click -> click -> type -> click chain can complete in
      // one fast burst with no gap for the browser to actually PAINT the
      // popup before the next click already fired. The end state came out
      // right (proven live: the pill correctly landed on "Rejected"), but
      // the reason submission depends on each step being real and
      // observable, not racing through DOM updates the browser never
      // rendered a frame for. These pauses force an actual paint between
      // each step, on the sandbox AND the real site alike -- this isn't
      // just for visibility, it's what makes the reason reliably reach
      // the input and Submit reliably see it before firing.
      await sleep(400);

      console.log("[clip-review-bot] clickVerdict: waiting for 'Give reason' button...");
      const giveReasonBtn = await pollFor(() => findByText("button", "Give reason"), { timeoutMs: 2000, intervalMs: 50 });
      if (!giveReasonBtn) {
        console.warn("[clip-review-bot] clickVerdict: 'Give reason' never appeared in time -- reject NOT confirmed with a reason.");
        return;
      }
      console.log("[clip-review-bot] clickVerdict: found 'Give reason', clicking...");
      giveReasonBtn.click();
      await sleep(400);

      console.log("[clip-review-bot] clickVerdict: waiting for the reason input...");
      const input = await pollFor(
        () => document.querySelector('input[placeholder="Reason for rejection..."]'),
        { timeoutMs: 1500, intervalMs: 50 }
      );
      if (!input) {
        console.warn("[clip-review-bot] clickVerdict: reason input never appeared in time.");
        return;
      }
      // Specific, clip-relevant reason from Gemini's own compliance notes --
      // never one of the 4 generic quick-select chips, per instruction.
      const finalReason = reasonText || "Does not meet campaign requirements.";
      console.log(`[clip-review-bot] clickVerdict: typing reason into input: "${finalReason}"`);
      setReactInputValue(input, finalReason);
      await sleep(400); // let React actually process the input event and (re-)enable Submit

      console.log("[clip-review-bot] clickVerdict: waiting for Submit to be enabled...");
      const submitBtn = await pollFor(() => findByText("button", "Submit"), { timeoutMs: 1000, intervalMs: 50 });
      if (submitBtn && !submitBtn.disabled) {
        console.log("[clip-review-bot] clickVerdict: clicking Submit...");
        submitBtn.click();
        await sleep(300); // let the submit-in-flight state actually paint before moving to the next card
        console.log("[clip-review-bot] clickVerdict: Submit clicked -- reject complete.");
      } else {
        console.warn("[clip-review-bot] clickVerdict: Submit button not ready/enabled in time.");
      }
      return;
    }

    // No "flag" case -- server.py only ever returns approve/reject now.
    // NEVER click .btn-warning-container ("Ban") for any verdict -- far
    // more severe and harder to reverse than reject; out of scope for
    // anything this bot should ever decide on its own.
  }

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    // all_frames:true means this script also runs in the outer whop.com
    // shell, which has none of this DOM -- only the apps.whop.com iframe
    // that actually holds the review UI should ever answer. Without this
    // check, both frames respond to the same broadcast and Chrome shows
    // whichever one lands first in the popup -- which was consistently
    // the outer shell's instant, wrong "not found" error, while the real
    // answer (30s later, real Apify+Gemini work) only ever showed up in
    // that iframe's own console. Silently ignoring here fixes the race by
    // leaving exactly one frame to respond at all.
    if (!document.querySelector(".analytics-section-bg")) return undefined;

    if (msg.type === "RUN_REVIEW") {
      // Respond immediately rather than awaiting the full loop -- with many
      // cards + scrolling, this can run for minutes, and Chrome's message
      // channel isn't reliable held open that long (this is what caused
      // "Couldn't reach this page" even though the page was fine). The loop
      // keeps running independently after this; watch the console for
      // per-card progress and the final count when it finishes.
      const initialCount = getCardElements().length;
      sendResponse({ ok: true, count: initialCount, note: "Started -- watch the console for progress on each submission (more may load as it scrolls)." });
      runAllCards().then((result) => console.log("[clip-review-bot] finished:", result));
      return undefined;
    }

    if (msg.type === "STOP_REVIEW") {
      stopRequested = true;
      console.log("[clip-review-bot] stop requested -- finishing the current submission, then halting.");
      sendResponse({ ok: true });
      return undefined;
    }

    return undefined;
  });
})();
