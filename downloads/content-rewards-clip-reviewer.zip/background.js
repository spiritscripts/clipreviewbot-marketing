// background.js -- MV3 service worker.
//
// Two jobs, both here rather than in content.js:
//  1. Call the review server. Content scripts on a real target page
//     (Whop's dashboard) may run under a page CSP that blocks fetch() to an
//     arbitrary origin -- service workers aren't subject to the page's CSP,
//     so all network calls funnel here.
//  2. Fetch profile-picture/thumbnail images as base64 when their `src` is
//     a real https:// URL (not already a data: URI). Doing this via
//     canvas.drawImage() + toDataURL() in the page would throw a
//     SecurityError on cross-origin images without CORS headers (very
//     likely on a real social-media CDN image); a plain fetch() from the
//     service worker has no such restriction.

// Was http://127.0.0.1:8787 during development -- that only ever worked on
// THIS machine, since it's literally "the reviewer's own laptop." Every
// other customer's install needs the real deployed server.
const SERVER_URL = "https://clipreviewbot-api.onrender.com";
// This is the real Clipbait backend (the same app.clipbait.ai the rest of
// this extension already treats as a first-party host in manifest.json),
// NOT the marketing site -- it's where /content-rewards-bot/status lives.
const CLIPBAIT_API_URL = "https://app.clipbait.ai";
const API_KEY_STORAGE_KEY = "crb_api_key";
// Same literal key popup.js's refreshGemFlash() already reads to drive the
// gem icon's flash/sparkle -- setting it here is the entire "unlock"
// signal, no other popup.js change needed for that part.
const SUBSCRIBED_KEY = "crb-subscribed";

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// A plain fetch() to a local server can fail with "TypeError: Failed to
// fetch" for reasons that have nothing to do with the submission itself --
// most commonly the server being mid-restart (this project's own dev
// workflow restarts it constantly while shipping fixes) or a brief port
// hiccup. Confirmed live: a real review request landed in exactly that
// kind of window and came back as an outright ERROR, losing the review
// entirely rather than just being slow. Retrying a few times before
// giving up means a few-second restart window doesn't cost a submission.
async function fetchReviewWithRetry(payload, attempt = 1) {
  const maxAttempts = 4;
  try {
    // The review server requires this now (real paywall gate, not just the
    // popup's own UI state) -- an expired/missing key gets a real 401/403
    // back, not a network error, so this isn't part of the retry-on-network-
    // blip logic below.
    const { [API_KEY_STORAGE_KEY]: apiKey } = await chrome.storage.local.get(API_KEY_STORAGE_KEY);
    const resp = await fetch(`${SERVER_URL}/review`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(apiKey ? { "X-API-Key": apiKey } : {}),
      },
      body: JSON.stringify(payload),
    });
    if (resp.status === 401 || resp.status === 403) {
      // FastAPI's HTTPException serializes as {"detail": "..."} -- not
      // {"message": ...}. Confirmed against server.py's actual raise calls.
      const data = await resp.json().catch(() => ({}));
      throw new Error(data.detail || "Your subscription isn't active. Open the extension's Premium tab to subscribe.");
    }
    return await resp.json();
  } catch (err) {
    if (err instanceof Error && (err.message.includes("subscription"))) throw err; // don't retry a real auth rejection
    if (attempt >= maxAttempts) throw err;
    await sleep(1500 * attempt); // 1.5s, 3s, 4.5s
    return fetchReviewWithRetry(payload, attempt + 1);
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "REVIEW_SUBMISSION") {
    fetchReviewWithRetry(msg.payload)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true; // keep the message channel open for the async response
  }

  if (msg.type === "FETCH_IMAGE_AS_DATA_URI") {
    fetchImageAsDataUri(msg.url)
      .then((dataUri) => sendResponse({ ok: true, dataUri }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg.type === "OPEN_BILLING_PORTAL") {
    openBillingPortal()
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg.type === "FETCH_STATUS") {
    fetchStatus()
      .then((status) => sendResponse({ ok: true, status }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg.type === "INVITE_SEAT") {
    inviteSeat(msg.email)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }

  if (msg.type === "REMOVE_SEAT") {
    removeSeat(msg.email)
      .then(() => sendResponse({ ok: true }))
      .catch((err) => sendResponse({ ok: false, error: String(err) }));
    return true;
  }
});

async function fetchImageAsDataUri(url) {
  const resp = await fetch(url);
  const contentType = resp.headers.get("content-type") || "image/jpeg";
  const buf = await resp.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return `data:${contentType};base64,${btoa(binary)}`;
}

// --- Web-to-extension auth handoff ------------------------------------------------------------
// Only pages on the origins listed in manifest.json's "externally_connectable"
// (the marketing site, plus localhost for dev) can even reach this listener
// at all -- that's enforced by Chrome itself before this code ever runs, not
// by the origin check below. The check below is a second, explicit guard
// against a future manifest edit accidentally widening that list further
// than intended.
const ALLOWED_HANDOFF_ORIGINS = ["https://clipreviewbot.clipbait.ai", "http://localhost:3000"];

chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg?.type !== "AUTH_HANDOFF") return undefined;
  if (!ALLOWED_HANDOFF_ORIGINS.includes(sender.origin)) {
    sendResponse({ ok: false, error: "untrusted_origin" });
    return undefined;
  }
  // Don't just trust whatever key the page handed over -- confirm it's a
  // real, subscribed Content Rewards Bot account before flipping
  // crb-subscribed (which the whole Premium/Team UI treats as "paid").
  verifyAndStoreApiKey(String(msg.apiKey || "").trim())
    .then((status) => sendResponse({ ok: true, status }))
    .catch((err) => sendResponse({ ok: false, error: String(err) }));
  return true; // async response
});

async function verifyAndStoreApiKey(apiKey) {
  if (!apiKey.startsWith("cbk_")) throw new Error("invalid_key");
  const resp = await fetch(`${CLIPBAIT_API_URL}/api/content-rewards-bot/status`, {
    headers: { "X-API-Key": apiKey },
  });
  if (!resp.ok) throw new Error(`status check failed (${resp.status})`);
  const status = await resp.json();
  await chrome.storage.local.set({
    [API_KEY_STORAGE_KEY]: apiKey,
    [SUBSCRIBED_KEY]: !!status.subscribed,
  });
  return status;
}

async function getStoredApiKey() {
  const { [API_KEY_STORAGE_KEY]: apiKey } = await chrome.storage.local.get(API_KEY_STORAGE_KEY);
  if (!apiKey) throw new Error("Not connected yet -- subscribe first.");
  return apiKey;
}

// --- Manage subscription -------------------------------------------------------
// Opens Stripe's hosted Billing Portal in a new tab -- lets the user update
// payment method, view invoices, or cancel without any of that being built
// into the extension itself.
async function openBillingPortal() {
  const apiKey = await getStoredApiKey();
  const resp = await fetch(`${CLIPBAIT_API_URL}/api/content-rewards-bot/create-portal-session`, {
    method: "POST",
    headers: { "X-API-Key": apiKey },
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok || !data.url) throw new Error(data.message || "Couldn't open billing portal.");
  await chrome.tabs.create({ url: data.url });
}

// --- Team seats -------------------------------------------------------
// Real backend calls now (see routes/contentRewardsBot.js) -- popup.js used
// to fake all of this in chrome.storage.local with no real invite ever
// sent. Routed through here rather than fetched directly from popup.js,
// same reasoning as the review-server calls: keeps every network call in
// one place holding the API key.
async function fetchStatus() {
  const apiKey = await getStoredApiKey();
  const resp = await fetch(`${CLIPBAIT_API_URL}/api/content-rewards-bot/status`, {
    headers: { "X-API-Key": apiKey },
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.message || "Couldn't load your account status.");
  return data;
}

async function inviteSeat(email) {
  const apiKey = await getStoredApiKey();
  const resp = await fetch(`${CLIPBAIT_API_URL}/api/content-rewards-bot/seats/invite`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-Key": apiKey },
    body: JSON.stringify({ email }),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.message || "Couldn't invite that email.");
  return data;
}

async function removeSeat(email) {
  const apiKey = await getStoredApiKey();
  const resp = await fetch(`${CLIPBAIT_API_URL}/api/content-rewards-bot/seats/remove`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-Key": apiKey },
    body: JSON.stringify({ email }),
  });
  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) throw new Error(data.message || "Couldn't remove that seat.");
  return data;
}
